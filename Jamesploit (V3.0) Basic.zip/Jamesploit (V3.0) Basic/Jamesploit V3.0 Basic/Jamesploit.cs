﻿// James Eckmeder
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
// WeAreDevs.dll
using WeAreDevs_API;

// I'm not the best at explaining my code lol. I will try my best though.

namespace Jamesploit_V3._0_Basic
{
    public partial class Jamesploit : Form
    {

        [DllImport("wininet.dll")]
        private extern static bool InternetGetConnectedState(out int Description, int ReservedValue);

        public Jamesploit()
        {
            InitializeComponent();
        }

        // Reference to the "WeAreDevs" API (api)
        ExploitAPI api = new ExploitAPI();
        // Reference to the "Open File" Window. (ofd)
        OpenFileDialog ofd = new OpenFileDialog();
        // Refrerence to the "Select A Folder" Window. (fbd)
        FolderBrowserDialog fbd = new FolderBrowserDialog();

        private void Jamesploit_Load(object sender, EventArgs e)
        {

        }

        private void Inject_Click(object sender, EventArgs e)
        {
            // Tries running the code, if success, nothing happens. If an exception is thrown, the "catch" function below will run.
            try
            {
                // Inject's the WeAreDevs api into the Roblox client (RobloxPlayerBeta.exe).
                api.LaunchExploit();
            }
            catch
            {
                int Desc;
                // Checks if the computer is not connected to the internet. If not, then the code in the brackets will run.
                if (InternetGetConnectedState(out Desc, 0) == false)
                {
                    // Lets the user know that their computer is not connected to the internet and that Jamesploit cannot inject the WeAreDev dll.
                    MessageBox.Show("An internet connection was not detected, please connect to the internet.", "No Internet", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                // Checks if the computer is connected to the internet. If yes, then the code in the brackets will run.
                else if (InternetGetConnectedState(out Desc, 0) == true)
                {
                    // Gives an error and that Jamesploit cannot continue.
                    if (MessageBox.Show("Jamesploit has encountered a fatal error and needs to quit, sorry!", "Fatal Error.", MessageBoxButtons.OK, MessageBoxIcon.Error) == DialogResult.OK)
                    {
                        // Forces the application to close, bypassing the closing confirmation window I have set.
                        Application.ExitThread();
                    }
                }
            }
        }

        private void ScriptBox_Load(object sender, EventArgs e)
        {

        }

        private void OpenFile_Click(object sender, EventArgs e)
        {
            // "Open File Window".
            // This filter only allows text files (.txt) to be selected.
            ofd.Filter = "TXT|*.txt";
            // Only continues the code if atext file has been selected.
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                // Sets the text in the ScriptBox to the text in the selected text file.
                ScriptBox.Text = File.ReadAllText(ofd.FileName);
            }
        }

        private void ClearScript_Click(object sender, EventArgs e)
        {
            // If "Yes" was clicked on the message box, then run the code, if not, then don't run the code.
            if (MessageBox.Show("Are you sure you want to clear the script? If you did not yet save the script it will be lost.", "Are you sure?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation) == DialogResult.Yes)
            {
                // Erases all text in the Script Box.
                ScriptBox.Text = "";
                // Displays a message stating that the Script Box was cleared.
                MessageBox.Show("Script cleared succesfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Execute_Click(object sender, EventArgs e)
        {
            // Executes the LUA script entered in the ScriptBox.
            api.SendLuaScript(ScriptBox.Text);
        }

        private void ClosingConfirmation(object sender, FormClosingEventArgs e)
        {
            // Displays a message box. The text in the front is the message, the text after that is the title, the code after that is what button(s) are shown, and the code after that sets the type of message it is.
            DialogResult dialog = MessageBox.Show("Are you sure you want to close? Any scripts currently open will be lost.", "Are you sure?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Exclamation);
            // If the butten pressed was "Yes"
            if (dialog == DialogResult.Yes)
            {
                // Closes the application.
                Application.ExitThread();
            }
            // If the button pressed was "No"
            else if (dialog == DialogResult.No)
            {
                // Does not close the application.
                e.Cancel = true;
            }
            // If the button pressed was "Cancel"
            else if (dialog == DialogResult.Cancel)
            {
                // Does not close the application.
                e.Cancel = true;
            }
        }
        private void DroppedFiles(object sender, DragEventArgs e)
        {
            // Detectes if a file was dragged onto the Script Box.
            e.Effect = DragDropEffects.All;
        }

        private void FilesDetected(object sender, DragEventArgs e)
        {
            // Gets the type of file and its name.
            string[] DroppedFiles = (string[])e.Data.GetData(DataFormats.FileDrop, false);
            // Assignes the file to a variable.
            foreach (string SelectedFile in DroppedFiles)
            {
                // Gets the text from the file and inserts it into the Script Box.
                var Contents = File.ReadAllText(SelectedFile);
                ScriptBox.Text = Contents;
            }
        }

        private void SaveScript_Click(object sender, EventArgs e)
        {
            // I'm not even gonna try to explain this lol.
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                if (File.Exists(fbd.SelectedPath + "/SavedScript.txt") == true)
                {
                    DialogResult dialog = MessageBox.Show("A file with the name 'SavedScript' already exists in the directory ( " + fbd.SelectedPath + " ). Would you like to overwrite it?", "File already exists.", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                    if (dialog == DialogResult.No)
                    {
                        MessageBox.Show("The operation was cancelled by the user.", "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else if (dialog == DialogResult.Yes)
                    {
                        try
                        {
                            StreamWriter File = new StreamWriter(fbd.SelectedPath + "/SavedScript.txt");
                            File.Write(ScriptBox.Text);
                            File.Close();
                            MessageBox.Show("Successfully saved script in '" + fbd.SelectedPath + "'.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch
                        {
                            MessageBox.Show("An unexpected error has occoured while attempting to save the current script. Please try again.", "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    try
                    {
                        StreamWriter File = new StreamWriter(fbd.SelectedPath + "/SavedScript.txt");
                        File.Write(ScriptBox.Text);
                        File.Close();
                        MessageBox.Show("Successfully saved script in '" + fbd.SelectedPath + "'.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch
                    {
                        MessageBox.Show("An unexpected error has occoured while attempting to save the current script. Please try again.", "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
// James Eckmeder