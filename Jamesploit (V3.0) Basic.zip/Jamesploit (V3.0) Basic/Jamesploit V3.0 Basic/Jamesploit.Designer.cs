﻿namespace Jamesploit_V3._0_Basic
{
    partial class Jamesploit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Jamesploit));
            this.ScriptBox = new FastColoredTextBoxNS.FastColoredTextBox();
            this.Inject = new System.Windows.Forms.Button();
            this.Execute = new System.Windows.Forms.Button();
            this.ClearScript = new System.Windows.Forms.Button();
            this.OpenFile = new System.Windows.Forms.Button();
            this.SaveScript = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ScriptBox)).BeginInit();
            this.SuspendLayout();
            // 
            // ScriptBox
            // 
            this.ScriptBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ScriptBox.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
            this.ScriptBox.AutoScrollMinSize = new System.Drawing.Size(1355, 252);
            this.ScriptBox.BackBrush = null;
            this.ScriptBox.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ScriptBox.CharHeight = 14;
            this.ScriptBox.CharWidth = 8;
            this.ScriptBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ScriptBox.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
            this.ScriptBox.IndentBackColor = System.Drawing.SystemColors.ScrollBar;
            this.ScriptBox.IsReplaceMode = false;
            this.ScriptBox.LineNumberColor = System.Drawing.SystemColors.WindowText;
            this.ScriptBox.Location = new System.Drawing.Point(12, 12);
            this.ScriptBox.Name = "ScriptBox";
            this.ScriptBox.Paddings = new System.Windows.Forms.Padding(0);
            this.ScriptBox.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.ScriptBox.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("ScriptBox.ServiceColors")));
            this.ScriptBox.Size = new System.Drawing.Size(710, 375);
            this.ScriptBox.TabIndex = 0;
            this.ScriptBox.Text = resources.GetString("ScriptBox.Text");
            this.ScriptBox.Zoom = 100;
            this.ScriptBox.Load += new System.EventHandler(this.ScriptBox_Load);
            this.ScriptBox.DragDrop += new System.Windows.Forms.DragEventHandler(this.DroppedFiles);
            this.ScriptBox.DragEnter += new System.Windows.Forms.DragEventHandler(this.FilesDetected);
            // 
            // Inject
            // 
            this.Inject.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Inject.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Inject.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Inject.Location = new System.Drawing.Point(12, 424);
            this.Inject.Name = "Inject";
            this.Inject.Size = new System.Drawing.Size(710, 25);
            this.Inject.TabIndex = 1;
            this.Inject.Text = "Inject";
            this.Inject.UseVisualStyleBackColor = true;
            this.Inject.Click += new System.EventHandler(this.Inject_Click);
            // 
            // Execute
            // 
            this.Execute.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Execute.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.Execute.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Execute.Location = new System.Drawing.Point(12, 393);
            this.Execute.Name = "Execute";
            this.Execute.Size = new System.Drawing.Size(172, 25);
            this.Execute.TabIndex = 2;
            this.Execute.Text = "Execute";
            this.Execute.UseVisualStyleBackColor = true;
            this.Execute.Click += new System.EventHandler(this.Execute_Click);
            // 
            // ClearScript
            // 
            this.ClearScript.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ClearScript.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.ClearScript.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearScript.Location = new System.Drawing.Point(190, 393);
            this.ClearScript.Name = "ClearScript";
            this.ClearScript.Size = new System.Drawing.Size(174, 25);
            this.ClearScript.TabIndex = 3;
            this.ClearScript.Text = "Clear Script";
            this.ClearScript.UseVisualStyleBackColor = true;
            this.ClearScript.Click += new System.EventHandler(this.ClearScript_Click);
            // 
            // OpenFile
            // 
            this.OpenFile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OpenFile.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.OpenFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpenFile.Location = new System.Drawing.Point(550, 393);
            this.OpenFile.Name = "OpenFile";
            this.OpenFile.Size = new System.Drawing.Size(172, 25);
            this.OpenFile.TabIndex = 4;
            this.OpenFile.Text = "Open File";
            this.OpenFile.UseVisualStyleBackColor = true;
            this.OpenFile.Click += new System.EventHandler(this.OpenFile_Click);
            // 
            // SaveScript
            // 
            this.SaveScript.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SaveScript.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.SaveScript.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveScript.Location = new System.Drawing.Point(369, 393);
            this.SaveScript.Name = "SaveScript";
            this.SaveScript.Size = new System.Drawing.Size(175, 25);
            this.SaveScript.TabIndex = 5;
            this.SaveScript.Text = "Save Script";
            this.SaveScript.UseVisualStyleBackColor = true;
            this.SaveScript.Click += new System.EventHandler(this.SaveScript_Click);
            // 
            // Jamesploit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ClientSize = new System.Drawing.Size(734, 461);
            this.Controls.Add(this.SaveScript);
            this.Controls.Add(this.OpenFile);
            this.Controls.Add(this.ClearScript);
            this.Controls.Add(this.Execute);
            this.Controls.Add(this.Inject);
            this.Controls.Add(this.ScriptBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Jamesploit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jamesploit V3.0 Basic";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ClosingConfirmation);
            this.Load += new System.EventHandler(this.Jamesploit_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ScriptBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private FastColoredTextBoxNS.FastColoredTextBox ScriptBox;
        private System.Windows.Forms.Button Inject;
        private System.Windows.Forms.Button Execute;
        private System.Windows.Forms.Button ClearScript;
        private System.Windows.Forms.Button OpenFile;
        private System.Windows.Forms.Button SaveScript;
    }
}

